-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #9
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_auth_rule` VALUES ('86', 'admin', '1', 'admin/Database/import', '恢复', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('87', 'admin', '1', 'admin/Database/del', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('88', 'admin', '1', 'admin/User/add', '新增用户', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('89', 'admin', '1', 'admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('90', 'admin', '1', 'admin/Attribute/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('91', 'admin', '1', 'admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('92', 'admin', '1', 'admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('93', 'admin', '1', 'admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('95', 'admin', '1', 'admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('100', 'admin', '1', 'admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('102', 'admin', '1', 'admin/Menu/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('103', 'admin', '1', 'admin/Menu/edit', '编辑', '1', '');
