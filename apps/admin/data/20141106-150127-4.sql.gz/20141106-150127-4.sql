-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #4
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------
-- Records of `winston_auth_rule`
-- -----------------------------
INSERT INTO `winston_auth_rule` VALUES ('1', 'admin', '2', 'admin/Index/index', '首页', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('2', 'admin', '2', 'admin/Article/mydocument', '内容', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('3', 'admin', '2', 'admin/User/index', '用户', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('4', 'admin', '2', 'admin/Addons/index', '扩展', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('5', 'admin', '2', 'admin/Config/group', '系统', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('7', 'admin', '1', 'admin/article/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('8', 'admin', '1', 'admin/article/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('9', 'admin', '1', 'admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('10', 'admin', '1', 'admin/article/update', '保存', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('11', 'admin', '1', 'admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('12', 'admin', '1', 'admin/article/move', '移动', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('13', 'admin', '1', 'admin/article/copy', '复制', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('14', 'admin', '1', 'admin/article/paste', '粘贴', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('15', 'admin', '1', 'admin/article/permit', '还原', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('16', 'admin', '1', 'admin/article/clear', '清空', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('17', 'admin', '1', 'admin/article/index', '文档列表', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('18', 'admin', '1', 'admin/article/recycle', '回收站', '1', '');
