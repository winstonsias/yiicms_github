-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #31
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_ucenter_member` VALUES ('1', 'winston', '900745484932ba618a8cbe33447add63', 'aa123@163.com', '', '1414392908', '2130706433', '1415234985', '127.0.0.1', '1414392908', '1');
INSERT INTO `winston_ucenter_member` VALUES ('2', 'a', '900745484932ba618a8cbe33447add63', 'test@163.com', '', '0', '0', '1415076089', '127.0.0.1', '0', '1');
INSERT INTO `winston_ucenter_member` VALUES ('3', 'd', '900745484932ba618a8cbe33447add63', 'winstonsias@qq.com', '', '0', '0', '0', '0', '0', '0');
INSERT INTO `winston_ucenter_member` VALUES ('4', 'x', '900745484932ba618a8cbe33447add63', 'xdd@163.com', '', '0', '0', '0', '0', '0', '1');
