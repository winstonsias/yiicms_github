-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #8
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_auth_rule` VALUES ('68', 'admin', '1', 'admin/Channel/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('69', 'admin', '1', 'admin/Channel/del', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('70', 'admin', '1', 'admin/Channel/index', '导航管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('71', 'admin', '1', 'admin/Category/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('72', 'admin', '1', 'admin/Category/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('73', 'admin', '1', 'admin/Category/remove', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('74', 'admin', '1', 'admin/Category/index', '分类管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('94', 'admin', '1', 'admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('79', 'admin', '1', 'admin/article/batchOperate', '导入', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('80', 'admin', '1', 'admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('81', 'admin', '1', 'admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('82', 'admin', '1', 'admin/Database/export', '备份', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('83', 'admin', '1', 'admin/Database/optimize', '优化表', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('84', 'admin', '1', 'admin/Database/repair', '修复表', '1', '');
