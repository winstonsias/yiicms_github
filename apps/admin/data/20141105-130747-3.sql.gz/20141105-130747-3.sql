-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #3
-- Date : 2014-11-05 13:07:48
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_auth_rule` VALUES ('18', 'admin', '1', 'admin/article/recycle', '回收站', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('19', 'admin', '1', 'admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('20', 'admin', '1', 'admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('21', 'admin', '1', 'admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('22', 'admin', '1', 'admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('23', 'admin', '1', 'admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('24', 'admin', '1', 'admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('25', 'admin', '1', 'admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('26', 'admin', '1', 'admin/User/index', '用户信息', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('27', 'admin', '1', 'admin/User/action', '用户行为', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('28', 'admin', '1', 'admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('29', 'admin', '1', 'admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('30', 'admin', '1', 'admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('31', 'admin', '1', 'admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('32', 'admin', '1', 'admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('33', 'admin', '1', 'admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('34', 'admin', '1', 'admin/AuthManager/group', '授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('35', 'admin', '1', 'admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('36', 'admin', '1', 'admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('37', 'admin', '1', 'admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('38', 'admin', '1', 'admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('39', 'admin', '1', 'admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('40', 'admin', '1', 'admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('41', 'admin', '1', 'admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('42', 'admin', '1', 'admin/Addons/create', '创建', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('43', 'admin', '1', 'admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('44', 'admin', '1', 'admin/Addons/preview', '预览', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('45', 'admin', '1', 'admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('46', 'admin', '1', 'admin/Addons/config', '设置', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('47', 'admin', '1', 'admin/Addons/disable', '禁用', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('48', 'admin', '1', 'admin/Addons/enable', '启用', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('49', 'admin', '1', 'admin/Addons/install', '安装', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('50', 'admin', '1', 'admin/Addons/uninstall', '卸载', '1', '');
