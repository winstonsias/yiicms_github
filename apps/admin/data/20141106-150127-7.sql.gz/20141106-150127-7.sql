-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #7
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_auth_rule` VALUES ('51', 'admin', '1', 'admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('52', 'admin', '1', 'admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('53', 'admin', '1', 'admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('54', 'admin', '1', 'admin/Addons/index', '插件管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('55', 'admin', '1', 'admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('56', 'admin', '1', 'admin/model/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('57', 'admin', '1', 'admin/model/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('58', 'admin', '1', 'admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('59', 'admin', '1', 'admin/model/update', '保存数据', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('60', 'admin', '1', 'admin/Model/index', '模型管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('61', 'admin', '1', 'admin/Config/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('62', 'admin', '1', 'admin/Config/del', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('63', 'admin', '1', 'admin/Config/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('64', 'admin', '1', 'admin/Config/save', '保存', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('65', 'admin', '1', 'admin/Config/group', '网站设置', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('66', 'admin', '1', 'admin/Config/index', '配置管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('67', 'admin', '1', 'admin/Channel/add', '新增', '1', '');
