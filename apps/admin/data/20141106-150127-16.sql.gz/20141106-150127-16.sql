-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #16
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('206', 'admin', '1', 'admin/think/edit', '编辑数据', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('207', 'admin', '1', 'admin/Menu/import', '导入', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('208', 'admin', '1', 'admin/Model/generate', '生成', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('209', 'admin', '1', 'admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('210', 'admin', '1', 'admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('211', 'admin', '1', 'admin/Article/sort', '文档排序', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('212', 'admin', '1', 'admin/Config/sort', '排序', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('213', 'admin', '1', 'admin/Menu/sort', '排序', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('214', 'admin', '1', 'admin/Channel/sort', '排序', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('215', 'admin', '1', 'admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('216', 'admin', '1', 'admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('219', 'admin', '2', 'admin/a/b', 'a1', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('220', 'admin', '1', 'admin/c', 'c', '1', '');
