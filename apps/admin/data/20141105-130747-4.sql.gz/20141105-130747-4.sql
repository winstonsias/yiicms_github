-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #4
-- Date : 2014-11-05 13:07:48
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_auth_rule` VALUES ('51', 'admin', '1', 'admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('52', 'admin', '1', 'admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('53', 'admin', '1', 'admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('54', 'admin', '1', 'admin/Addons/index', '插件管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('55', 'admin', '1', 'admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('56', 'admin', '1', 'admin/model/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('57', 'admin', '1', 'admin/model/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('58', 'admin', '1', 'admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('59', 'admin', '1', 'admin/model/update', '保存数据', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('60', 'admin', '1', 'admin/Model/index', '模型管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('61', 'admin', '1', 'admin/Config/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('62', 'admin', '1', 'admin/Config/del', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('63', 'admin', '1', 'admin/Config/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('64', 'admin', '1', 'admin/Config/save', '保存', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('65', 'admin', '1', 'admin/Config/group', '网站设置', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('66', 'admin', '1', 'admin/Config/index', '配置管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('67', 'admin', '1', 'admin/Channel/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('68', 'admin', '1', 'admin/Channel/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('69', 'admin', '1', 'admin/Channel/del', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('70', 'admin', '1', 'admin/Channel/index', '导航管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('71', 'admin', '1', 'admin/Category/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('72', 'admin', '1', 'admin/Category/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('73', 'admin', '1', 'admin/Category/remove', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('74', 'admin', '1', 'admin/Category/index', '分类管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('94', 'admin', '1', 'admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('79', 'admin', '1', 'admin/article/batchOperate', '导入', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('80', 'admin', '1', 'admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('81', 'admin', '1', 'admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('82', 'admin', '1', 'admin/Database/export', '备份', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('83', 'admin', '1', 'admin/Database/optimize', '优化表', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('84', 'admin', '1', 'admin/Database/repair', '修复表', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('86', 'admin', '1', 'admin/Database/import', '恢复', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('87', 'admin', '1', 'admin/Database/del', '删除', '1', '');
