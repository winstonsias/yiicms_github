-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #5
-- Date : 2014-11-05 13:07:48
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_auth_rule` VALUES ('88', 'admin', '1', 'admin/User/add', '新增用户', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('89', 'admin', '1', 'admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('90', 'admin', '1', 'admin/Attribute/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('91', 'admin', '1', 'admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('92', 'admin', '1', 'admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('93', 'admin', '1', 'admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('95', 'admin', '1', 'admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('100', 'admin', '1', 'admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('102', 'admin', '1', 'admin/Menu/add', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('103', 'admin', '1', 'admin/Menu/edit', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('105', 'admin', '1', 'admin/Think/lists?model=download', '下载管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('106', 'admin', '1', 'admin/Think/lists?model=config', '配置管理', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('107', 'admin', '1', 'admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('108', 'admin', '1', 'admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('109', 'admin', '1', 'admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('110', 'admin', '1', 'admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('205', 'admin', '1', 'admin/think/add', '新增数据', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `winston_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
