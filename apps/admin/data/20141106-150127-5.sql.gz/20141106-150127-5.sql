-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #5
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_auth_rule` VALUES ('19', 'admin', '1', 'admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('20', 'admin', '1', 'admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('21', 'admin', '1', 'admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('22', 'admin', '1', 'admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('23', 'admin', '1', 'admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('24', 'admin', '1', 'admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('25', 'admin', '1', 'admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('26', 'admin', '1', 'admin/User/index', '用户信息', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('27', 'admin', '1', 'admin/User/action', '用户行为', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('28', 'admin', '1', 'admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('29', 'admin', '1', 'admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('30', 'admin', '1', 'admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('31', 'admin', '1', 'admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('32', 'admin', '1', 'admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `winston_auth_rule` VALUES ('33', 'admin', '1', 'admin/AuthManager/writeGroup', '保存用户组', '1', '');
