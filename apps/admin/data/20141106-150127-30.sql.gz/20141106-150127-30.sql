-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #30
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `winston_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0');
INSERT INTO `winston_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0');
INSERT INTO `winston_menu` VALUES ('129', 'a1', '0', '0', 'a/b', '0', '', '', '0');
INSERT INTO `winston_menu` VALUES ('136', 'c', '129', '0', 'c', '0', '', '', '0');
INSERT INTO `winston_menu` VALUES ('135', 'b', '129', '0', 'b', '0', '', '', '0');
INSERT INTO `winston_menu` VALUES ('134', 'a', '129', '0', 'a', '0', '', '', '0');

-- -----------------------------
-- Table structure for `winston_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `winston_ucenter_member`;
CREATE TABLE `winston_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` varchar(255) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `winston_ucenter_member`
-- -----------------------------
