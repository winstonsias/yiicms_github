-- -----------------------------
-- SQL Data Transfer 
-- 
-- DSN     : mysql:host=localhost;dbname=yiicms
-- 
-- Part : #22
-- Date : 2014-11-06 15:01:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------
-- Records of `winston_member`
-- -----------------------------
INSERT INTO `winston_member` VALUES ('1', 'winston', '0', '0000-00-00', '', '10', '18', '0', '1414392908', '127.0.0.1', '1415234984', '1');
INSERT INTO `winston_member` VALUES ('2', 'a', '0', '0000-00-00', '', '0', '1', '0', '0', '127.0.0.1', '1415076089', '1');
INSERT INTO `winston_member` VALUES ('3', 'd', '0', '0000-00-00', '', '0', '0', '0', '0', '0.0.0.0', '0', '1');
INSERT INTO `winston_member` VALUES ('4', 'x', '0', '0000-00-00', '', '0', '0', '0', '0', '0.0.0.0', '0', '-1');
INSERT INTO `winston_member` VALUES ('25', '', '0', '0000-00-00', '', '0', '0', '0', '0', '0.0.0.0', '0', '0');

-- -----------------------------
-- Table structure for `winston_menu`
-- -----------------------------
DROP TABLE IF EXISTS `winston_menu`;
CREATE TABLE `winston_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=137 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `winston_menu`
-- -----------------------------
INSERT INTO `winston_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0');
INSERT INTO `winston_menu` VALUES ('2', '内容', '0', '2', 'Article/mydocument', '0', '', '', '0');
INSERT INTO `winston_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0');
